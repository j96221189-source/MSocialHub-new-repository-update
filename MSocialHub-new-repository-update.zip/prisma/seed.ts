import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();

async function main() {
  const services = [
    {
      slug: "starter-content-pack",
      name: "Starter Content Pack",
      description: "Eight branded social posts with captions, delivered as a monthly content pack.",
      category: "Content Creation",
      platform: "Multi-platform",
      priceCents: 19900,
      minQuantity: 1,
      maxQuantity: 1,
      deliveryNote: "Delivery schedule confirmed after onboarding"
    },
    {
      slug: "social-calendar",
      name: "Social Content Calendar",
      description: "A four-week content calendar with post ideas, captions and recommended publishing dates.",
      category: "Strategy",
      platform: "Multi-platform",
      priceCents: 9900,
      minQuantity: 1,
      maxQuantity: 1,
      deliveryNote: "Delivered after client briefing"
    },
    {
      slug: "monthly-management",
      name: "Monthly Social Management",
      description: "Twelve posts, captions, scheduling coordination and a monthly performance summary.",
      category: "Management",
      platform: "Two platforms",
      priceCents: 34900,
      minQuantity: 1,
      maxQuantity: 1,
      deliveryNote: "Requires onboarding and client content approval"
    }
  ];

  for (const service of services) {
    await prisma.service.upsert({
      where: { slug: service.slug },
      update: service,
      create: service
    });
  }

  await prisma.supplierConfig.upsert({
    where: { id: "default" },
    update: { mode: "MOCK", liveEnabled: false },
    create: { id: "default", mode: "MOCK", liveEnabled: false }
  });
}

main().finally(async () => prisma.$disconnect());
