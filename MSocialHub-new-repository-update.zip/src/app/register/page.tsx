import Link from "next/link";
import { redirect } from "next/navigation";
import { registerAction } from "@/app/register/actions";
import { getCurrentUser } from "@/lib/auth";

const ERRORS: Record<string, string> = {
  invalid: "Please check the form: name 2–80 characters, a valid email, and a password of 12–72 characters.",
  exists: "An account with that email already exists. Try signing in instead."
};

export default async function RegisterPage({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  if (await getCurrentUser()) redirect("/dashboard");
  const { error } = await searchParams;
  return <section className="form-wrap">
    <span className="eyebrow">GET STARTED</span><h1 style={{fontSize:42}}>Create your account.</h1>
    {error && <div className="notice" role="alert">{ERRORS[error] ?? ERRORS.invalid}</div>}
    <p>Use a unique password. Email verification should be enabled before public launch.</p>
    <form action={registerAction} className="panel" style={{marginTop:22}}>
      <label className="label">Name<input className="input" name="name" required minLength={2} maxLength={80} autoComplete="name"/></label>
      <label className="label">Email<input className="input" name="email" type="email" required maxLength={254} autoComplete="email"/></label>
      <label className="label">Password<input className="input" name="password" type="password" required minLength={12} maxLength={72} autoComplete="new-password"/><span className="muted" style={{fontSize:11}}>Use 12–72 characters.</span></label>
      <button className="btn" type="submit" style={{width:"100%"}}>Create account</button>
    </form>
    <p style={{fontSize:13}}>Already registered? <Link href="/login" style={{textDecoration:"underline"}}>Sign in</Link></p>
  </section>;
}
