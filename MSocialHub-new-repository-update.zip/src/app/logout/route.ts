import { NextResponse } from "next/server";
import { SESSION_COOKIE, cookieOptions } from "@/lib/auth";

// Use a relative Location header. Building an absolute URL from request.url
// produced http://0.0.0.0:3000/ when the server binds to 0.0.0.0, which the
// browser cannot open (it showed chrome-error://chromewebdata/).
function signOut() {
  const response = new NextResponse(null, { status: 303, headers: { Location: "/" } });
  response.cookies.set(SESSION_COOKIE, "", cookieOptions(0));
  response.headers.set("Cache-Control", "no-store");
  return response;
}

export async function POST() {
  return signOut();
}

// A direct visit to /logout also signs out instead of returning 405.
export async function GET() {
  return signOut();
}
