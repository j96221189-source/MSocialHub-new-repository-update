import Link from "next/link";
import { redirect } from "next/navigation";
import { loginAction } from "@/app/login/actions";
import { getCurrentUser } from "@/lib/auth";

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  if (await getCurrentUser()) redirect("/dashboard");
  const { error } = await searchParams;
  return <section className="form-wrap">
    <span className="eyebrow">WELCOME BACK</span><h1 style={{fontSize:42}}>Sign in.</h1>
    {error && <div className="notice" role="alert">Incorrect email or password.</div>}
    <form action={loginAction} className="panel" style={{marginTop:22}}>
      <label className="label">Email<input className="input" name="email" type="email" required autoComplete="email"/></label>
      <label className="label">Password<input className="input" name="password" type="password" required autoComplete="current-password"/></label>
      <button className="btn" type="submit" style={{width:"100%"}}>Sign in</button>
    </form>
    <p style={{fontSize:13}}>New here? <Link href="/register" style={{textDecoration:"underline"}}>Create an account</Link></p>
  </section>;
}
