import Link from "next/link";
import { ArrowUpRight, CalendarDays, ChartNoAxesCombined, ShieldCheck } from "lucide-react";

export default function HomePage() {
  return <>
    <section className="hero">
      <div>
        <span className="eyebrow">YOUR SOCIAL SERVICES · ONE HUB</span>
        <h1>Your social services.<br/>One hub.</h1>
        <p style={{fontSize:18,maxWidth:560}}>Plan, order and track social media content services from one calm, straightforward dashboard.</p>
        <div style={{display:"flex",gap:12,flexWrap:"wrap",marginTop:25}}>
          <Link className="btn" href="/services">Explore services <ArrowUpRight size={16}/></Link>
          <Link className="btn secondary" href="/register">Create account</Link>
        </div>
        <p style={{fontSize:12,marginTop:18}}>Transparent deliverables. Human-reviewed fulfillment. No promises of artificial engagement.</p>
      </div>
      <div className="panel">
        <div className="row"><span className="muted" style={{fontSize:13}}>WORKSPACE PREVIEW</span><span className="pill">DEMO</span></div>
        <div style={{marginTop:26}}><div className="muted" style={{fontSize:12}}>Active projects</div><div className="metric">03</div></div>
        <div style={{height:1,background:"var(--border)",margin:"22px 0"}}/>
        <div className="row"><div><div style={{fontWeight:700}}>Monthly content calendar</div><div className="muted" style={{fontSize:12,marginTop:5}}>Awaiting onboarding</div></div><span className="pill">Review</span></div>
        <div className="row" style={{marginTop:20}}><div><div style={{fontWeight:700}}>Content pack</div><div className="muted" style={{fontSize:12,marginTop:5}}>Example project</div></div><span className="pill">Queued</span></div>
      </div>
    </section>
    <section className="section">
      <div style={{maxWidth:600,marginBottom:24}}><h2>A cleaner way to manage the work</h2><p>Start with a focused catalog and clear order tracking. Expand automation only when the workflow and suppliers have been verified.</p></div>
      <div className="grid">
        <div className="panel"><CalendarDays/><h3 style={{marginTop:18}}>Content planning</h3><p>Editorial calendars, captions and creative deliverables with a clear scope.</p></div>
        <div className="panel"><ChartNoAxesCombined/><h3 style={{marginTop:18}}>Order visibility</h3><p>Track each request from submission through review and completion.</p></div>
        <div className="panel"><ShieldCheck/><h3 style={{marginTop:18}}>Safer by design</h3><p>Supplier integration remains mocked and live purchases are disabled by default.</p></div>
      </div>
    </section>
  </>;
}
