import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { money } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function ServicesPage() {
  const services = await prisma.service.findMany({ where: { active: true }, orderBy: { priceCents: "asc" } });
  return <section className="section">
    <span className="eyebrow">SERVICE CATALOG</span>
    <h1 style={{fontSize:44}}>Services with a clear scope.</h1>
    <p style={{maxWidth:640}}>Choose content and management services with defined deliverables. Prices below are starter examples and can be edited by an administrator.</p>
    <div className="grid" style={{marginTop:30}}>
      {services.map(s => <article className="panel" key={s.id}>
        <span className="pill">{s.category}</span>
        <h3 style={{marginTop:16}}>{s.name}</h3>
        <p>{s.description}</p>
        <div className="row" style={{marginTop:20}}><div className="metric">{money(s.priceCents,s.currency)}<span className="muted" style={{fontSize:12,fontWeight:400}}>/ package</span></div></div>
        <p style={{fontSize:12}}>{s.deliveryNote}</p>
        <Link href="/dashboard/new-order" className="btn secondary" style={{marginTop:8}}>Create an order</Link>
      </article>)}
    </div>
    {services.length === 0 && <div className="panel">No active services yet. Run `npm run db:seed` to load sample content services.</div>}
  </section>;
}
