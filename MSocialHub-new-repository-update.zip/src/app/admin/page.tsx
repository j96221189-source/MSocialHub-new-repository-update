import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { money } from "@/lib/format";
import { saveSupplierGateAction, toggleServiceAction, updateOrderStatusAction, updateServicePricingAction } from "./actions";
import { calculatePrice } from "@/lib/pricing";

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (user.role !== "ADMIN") redirect("/dashboard");
  const [services, orders, users, config] = await Promise.all([
    prisma.service.findMany({ orderBy: { createdAt: "desc" } }),
    prisma.order.findMany({ include: { user: true, items: true }, orderBy: { createdAt: "desc" }, take: 30 }),
    prisma.user.count(),
    prisma.supplierConfig.findUnique({ where: { id: "default" } })
  ]);
  return <section className="section">
    <span className="eyebrow">ADMINISTRATION</span><h1 style={{fontSize:42}}>Control room.</h1>
    <div className="notice">Live supplier calls are not implemented. This panel cannot enable live mode. All supplier activity is mocked.</div>
    <div className="grid" style={{marginTop:20}}>
      <div className="panel"><div className="muted" style={{fontSize:12}}>Registered users</div><div className="metric">{users}</div></div>
      <div className="panel"><div className="muted" style={{fontSize:12}}>Catalog services</div><div className="metric">{services.length}</div></div>
      <div className="panel"><div className="muted" style={{fontSize:12}}>Supplier mode</div><div className="metric" style={{fontSize:22}}>MOCK</div><span className="pill">LIVE DISABLED</span></div>
    </div>

    <div className="panel" style={{marginTop:22}}>
      <h2 style={{fontSize:20}}>Service catalog</h2><div style={{overflowX:"auto"}}><table className="table"><thead><tr><th>Service</th><th>Customer price</th><th>Supplier cost</th><th>Markup / gross profit</th><th>Visibility</th><th>Actions</th></tr></thead><tbody>
        {services.map(s=>{ const breakdown = s.supplierCostCents == null ? null : calculatePrice(s.supplierCostCents, s.markupPercent ?? config?.defaultMarkupPercent ?? 50); return <tr key={s.id}><td><strong>{s.name}</strong><div className="muted">{s.slug}</div></td><td>{money(s.priceCents,s.currency)}</td><td>{s.supplierCostCents == null ? "Not set" : money(s.supplierCostCents,"USD")}</td><td>{breakdown ? <>{breakdown.markupPercent}% markup<div className="muted">{money(breakdown.grossProfitCents,"USD")} gross profit · {breakdown.grossMarginPercent.toFixed(2)}% margin</div></> : "Awaiting verified cost"}</td><td>{s.active?"Active":"Hidden"}</td><td><form action={updateServicePricingAction} className="stack" style={{gap:6,marginBottom:8}}><input type="hidden" name="id" value={s.id}/><label className="label">Supplier cost (cents)<input className="input" type="number" name="supplierCostCents" min="0" step="1" required defaultValue={s.supplierCostCents ?? ""} placeholder="e.g. 200"/></label><label className="label">Markup (%)<input className="input" type="number" name="markupPercent" min="0" max="1000" step="0.1" required defaultValue={s.markupPercent ?? config?.defaultMarkupPercent ?? 50}/></label><button className="btn secondary" type="submit">Save pricing</button></form><form action={toggleServiceAction}><input type="hidden" name="id" value={s.id}/><input type="hidden" name="active" value={s.active?"false":"true"}/><button className="btn secondary" type="submit">{s.active?"Hide":"Activate"}</button></form></td></tr>})}
      </tbody></table></div>
    </div>

    <div className="panel" style={{marginTop:22}}>
      <h2 style={{fontSize:20}}>Recent orders</h2><div style={{overflowX:"auto"}}><table className="table"><thead><tr><th>Order / customer</th><th>Total</th><th>Status</th><th>Update status</th></tr></thead><tbody>
        {orders.map(o=><tr key={o.id}><td>#{o.publicId.slice(-8)}<div className="muted">{o.user.email}</div><div className="muted">{o.items.map(i=>i.serviceName).join(", ")}</div></td><td>{money(o.totalCents,o.currency)}</td><td>{o.status}</td><td><form action={updateOrderStatusAction} className="stack" style={{gap:6}}><input type="hidden" name="id" value={o.id}/><select className="input" name="status" defaultValue={o.status === "PENDING_PAYMENT" || o.status === "PAID" ? "AWAITING_FULFILLMENT" : o.status}><option value="AWAITING_FULFILLMENT">Awaiting fulfillment</option><option value="PROCESSING">Processing</option><option value="COMPLETED">Completed</option><option value="PARTIAL">Partial</option><option value="FAILED">Failed</option><option value="CANCELLED">Cancelled</option><option value="REFUND_PENDING">Refund pending</option><option value="REFUNDED">Refunded</option></select><button className="btn secondary" type="submit">Save</button></form></td></tr>)}
        {orders.length===0 && <tr><td colSpan={4}>No orders yet.</td></tr>}
      </tbody></table></div>
    </div>

    <div className="panel" style={{marginTop:22}}>
      <h2 style={{fontSize:20}}>Supplier verification record</h2>
      <p>Pricing uses supplier cost plus markup. Saving a cost updates the current catalog price; it does not rewrite existing order snapshots. Leave cost unset until it is verified from the supplier API. This panel still cannot activate the live supplier.</p>
      <div className="row" style={{justifyContent:"start",marginBottom:12}}><span className="pill">Mode: {config?.mode ?? "MOCK"}</span><span className="pill">Live enabled: No</span><span className="pill">Verified at: {config?.verifiedAt ? config.verifiedAt.toLocaleDateString() : "Not recorded"}</span></div>
      <form action={saveSupplierGateAction}><label className="label">Review notes<textarea className="input" name="notes" rows={3} maxLength={1000} defaultValue={config?.notes ?? ""} placeholder="Record evidence checked, policy review and outstanding questions."/></label><button className="btn secondary" type="submit">Save review notes</button></form>
    </div>
    <form action="/logout" method="post" style={{marginTop:18}}><button className="btn secondary" type="submit">Sign out</button></form>
  </section>;
}
