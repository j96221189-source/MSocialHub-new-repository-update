"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { requireAdmin } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { calculatePrice } from "@/lib/pricing";

export async function toggleServiceAction(formData: FormData) {
  await requireAdmin();
  const parsed = z.object({ id: z.string().min(1).max(64), active: z.enum(["true","false"]) }).safeParse({
    id: formData.get("id"), active: formData.get("active")
  });
  if (!parsed.success) throw new Error("Invalid service update.");
  await prisma.service.updateMany({ where: { id: parsed.data.id }, data: { active: parsed.data.active === "true" } });
  revalidatePath("/admin");
  revalidatePath("/services");
}

export async function updateOrderStatusAction(formData: FormData) {
  const admin = await requireAdmin();
  const parsed = z.object({
    id: z.string().min(1).max(64),
    status: z.enum(["AWAITING_FULFILLMENT","PROCESSING","COMPLETED","PARTIAL","FAILED","CANCELLED","REFUND_PENDING","REFUNDED"])
  }).safeParse({ id: formData.get("id"), status: formData.get("status") });
  if (!parsed.success) throw new Error("Invalid order status.");
  const { count } = await prisma.order.updateMany({ where: { id: parsed.data.id }, data: { status: parsed.data.status } });
  if (count === 0) throw new Error("Order not found.");
  await prisma.auditLog.create({ data: { actorId: admin.id, action: "ORDER_STATUS_CHANGED", targetType: "Order", targetId: parsed.data.id, metadata: { status: parsed.data.status } } });
  revalidatePath("/admin");
  revalidatePath("/dashboard");
  revalidatePath("/dashboard/orders");
}

export async function saveSupplierGateAction(formData: FormData) {
  const admin = await requireAdmin();
  const parsed = z.object({ notes: z.string().trim().max(1000) }).safeParse({ notes: String(formData.get("notes") ?? "") });
  if (!parsed.success) throw new Error("Review notes must be 1,000 characters or fewer.");
  const note = parsed.data.notes;
  // Live mode is intentionally impossible to enable from this UI.
  await prisma.supplierConfig.upsert({
    where: { id: "default" },
    update: { mode: "MOCK", liveEnabled: false, notes: note },
    create: { id: "default", mode: "MOCK", liveEnabled: false, notes: note }
  });
  await prisma.auditLog.create({ data: { actorId: admin.id, action: "SUPPLIER_REVIEW_NOTE_UPDATED", targetType: "SupplierConfig", targetId: "default" } });
  revalidatePath("/admin");
}

export async function updateServicePricingAction(formData: FormData) {
  const admin = await requireAdmin();
  const parsed = z.object({
    id: z.string().min(1).max(64),
    supplierCostCents: z.coerce.number().int().min(0).max(100000000),
    markupPercent: z.coerce.number().min(0).max(1000)
  }).safeParse({
    id: formData.get("id"),
    supplierCostCents: formData.get("supplierCostCents"),
    markupPercent: formData.get("markupPercent")
  });
  if (!parsed.success) throw new Error("Enter a valid supplier cost and markup.");
  const price = calculatePrice(parsed.data.supplierCostCents, parsed.data.markupPercent);
  const { count } = await prisma.service.updateMany({
    where: { id: parsed.data.id },
    data: { supplierCostCents: price.supplierCostCents, markupPercent: price.markupPercent, priceCents: price.customerPriceCents, currency: "USD" }
  });
  if (!count) throw new Error("Service not found.");
  await prisma.auditLog.create({ data: { actorId: admin.id, action: "SERVICE_PRICING_UPDATED", targetType: "Service", targetId: parsed.data.id, metadata: { supplierCostCents: price.supplierCostCents, markupPercent: price.markupPercent, customerPriceCents: price.customerPriceCents } } });
  revalidatePath("/admin");
  revalidatePath("/services");
  revalidatePath("/api/services");
}
