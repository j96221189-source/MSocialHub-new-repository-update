import type { Metadata } from "next";
import Link from "next/link";
import { getCurrentUser } from "@/lib/auth";
import "./globals.css";

export const metadata: Metadata = {
  title: "MSocialHub — Your social services. One hub.",
  description: "MSocialHub — Your social services. One hub."
};

export default async function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  const user = await getCurrentUser();
  return <html lang="en"><body>
    <header className="shell nav">
      <Link href="/" className="brand">MSOCIAL<span>HUB</span></Link>
      <nav className="navlinks">
        <Link href="/services">Services</Link>
        <Link href="/dashboard">Dashboard</Link>
        {user?.role === "ADMIN" && <Link href="/admin">Admin</Link>}
        {user
          ? <form action="/logout" method="post" style={{display:"inline"}}><button type="submit" style={{background:"none",border:0,padding:0,font:"inherit",color:"inherit",cursor:"pointer"}}>Sign out</button></form>
          : <Link href="/login">Sign in</Link>}
      </nav>
    </header>
    <main className="shell">{children}</main>
    <footer className="shell footer row">
      <span>© {new Date().getFullYear()} MSocialHub</span>
      <span>Mock supplier mode · Live ordering disabled</span>
    </footer>
  </body></html>;
}
