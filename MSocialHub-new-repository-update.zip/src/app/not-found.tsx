import Link from "next/link";
export default function NotFound() {
  return <section className="section"><h1 style={{fontSize:42}}>Page not found.</h1><p>That route doesn't exist in this workspace.</p><Link className="btn" href="/">Return home</Link></section>;
}
