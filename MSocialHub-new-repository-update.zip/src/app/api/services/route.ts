import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const services = await prisma.service.findMany({
    where: { active: true },
    select: { id: true, slug: true, name: true, description: true, category: true, platform: true, priceCents: true, currency: true, minQuantity: true, maxQuantity: true, deliveryNote: true },
    orderBy: { priceCents: "asc" }
  });
  return NextResponse.json({ mode: "mock", liveSupplierEnabled: false, services });
}
