import { createHmac, timingSafeEqual } from "node:crypto";
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export const runtime = "nodejs";

function sortObject(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(sortObject);
  if (value && typeof value === "object") {
    return Object.fromEntries(Object.entries(value as Record<string, unknown>).sort(([a], [b]) => a.localeCompare(b)).map(([k, v]) => [k, sortObject(v)]));
  }
  return value;
}

export async function POST(request: NextRequest) {
  const secret = process.env.NOWPAYMENTS_IPN_SECRET;
  if (!secret) return NextResponse.json({ error: "Webhook not configured" }, { status: 503 });
  const raw = await request.text();
  let body: Record<string, unknown>;
  try { body = JSON.parse(raw) as Record<string, unknown>; }
  catch { return NextResponse.json({ error: "Invalid JSON" }, { status: 400 }); }

  const supplied = request.headers.get("x-nowpayments-sig") ?? "";
  const expected = createHmac("sha512", secret).update(JSON.stringify(sortObject(body))).digest("hex");
  const a = Buffer.from(supplied, "utf8");
  const b = Buffer.from(expected, "utf8");
  if (a.length !== b.length || !timingSafeEqual(a, b)) return NextResponse.json({ error: "Invalid signature" }, { status: 401 });

  const orderId = typeof body.order_id === "string" ? body.order_id : "";
  const paymentId = body.payment_id === undefined ? "" : String(body.payment_id);
  const status = typeof body.payment_status === "string" ? body.payment_status : "";
  const amount = Number(body.price_amount);
  const currency = typeof body.price_currency === "string" ? body.price_currency.toUpperCase() : "";
  const allowedStatuses = new Set(["waiting", "confirming", "confirmed", "sending", "partially_paid", "finished", "failed", "expired", "refunded"]);
  if (!orderId || !paymentId || !allowedStatuses.has(status) || !currency || !Number.isFinite(amount) || amount <= 0) {
    return NextResponse.json({ error: "Missing or invalid payment fields" }, { status: 400 });
  }

  const order = await prisma.order.findUnique({ where: { id: orderId }, include: { payments: true } });
  if (!order) return NextResponse.json({ error: "Order not found" }, { status: 404 });
  if (currency !== order.currency.toUpperCase()) return NextResponse.json({ error: "Currency mismatch" }, { status: 400 });
  if (Math.round(amount * 100) !== order.totalCents) return NextResponse.json({ error: "Amount mismatch" }, { status: 400 });

  const finalPaid = status === "finished";
  const refunded = status === "refunded";
  const failed = ["failed", "expired"].includes(status);
  await prisma.$transaction(async tx => {
    const existing = await tx.payment.findFirst({ where: { orderId, provider: "NOWPAYMENTS" } });
    if (existing) {
      const nextStatus = finalPaid ? "SUCCEEDED" : refunded ? "REFUNDED" : failed ? "FAILED" : "PENDING";
      const terminal = existing.status === "SUCCEEDED" || existing.status === "REFUNDED";
      // A delayed duplicate waiting/confirming notification must never downgrade a terminal payment.
      if (!terminal || finalPaid || refunded) {
        await tx.payment.update({ where: { id: existing.id }, data: { providerPaymentId: paymentId, status: nextStatus } });
      }
    } else {
      await tx.payment.create({ data: { orderId, provider: "NOWPAYMENTS", providerPaymentId: paymentId, amountCents: order.totalCents, currency: order.currency, status: finalPaid ? "SUCCEEDED" : refunded ? "REFUNDED" : failed ? "FAILED" : "PENDING" } });
    }
    if (finalPaid && order.paymentStatus !== "SUCCEEDED") {
      await tx.order.update({ where: { id: orderId }, data: { paymentStatus: "SUCCEEDED", status: "AWAITING_FULFILLMENT", paymentRef: paymentId } });
    } else if (refunded && order.paymentStatus === "SUCCEEDED") {
      await tx.order.update({ where: { id: orderId }, data: { paymentStatus: "REFUNDED", status: "REFUNDED" } });
    } else if (failed && order.paymentStatus !== "SUCCEEDED" && order.paymentStatus !== "REFUNDED") {
      await tx.order.update({ where: { id: orderId }, data: { paymentStatus: "FAILED", status: "FAILED" } });
    }
    await tx.auditLog.create({ data: { action: "NOWPAYMENTS_IPN_RECEIVED", targetType: "Order", targetId: orderId, metadata: { paymentId, status } } });
  });
  return NextResponse.json({ received: true });
}
