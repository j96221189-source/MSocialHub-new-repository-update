import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  try {
    await prisma.$queryRaw`SELECT 1`;
    return NextResponse.json({ ok: true, database: "connected", supplierMode: "mock", liveSupplierEnabled: false });
  } catch {
    return NextResponse.json({ ok: false, database: "unavailable", supplierMode: "mock", liveSupplierEnabled: false }, { status: 503 });
  }
}
