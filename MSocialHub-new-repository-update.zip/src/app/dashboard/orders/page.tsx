import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { money } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function OrdersPage({ searchParams }: { searchParams: Promise<{ created?: string }> }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const { created } = await searchParams;
  const orders = await prisma.order.findMany({ where: { userId: user.id }, include: { items: true }, orderBy: { createdAt: "desc" } });
  return <section className="section"><span className="eyebrow">ORDER HISTORY</span><h1 style={{fontSize:42}}>My requests</h1>
    {created && <div className="notice" role="status">Request created. It is waiting for manual payment confirmation.</div>}
    <div className="panel" style={{overflowX:"auto",marginTop:20}}><table className="table"><thead><tr><th>Order</th><th>Service</th><th>Status</th><th>Payment</th><th>Total</th><th>Date</th></tr></thead><tbody>
      {orders.map(o=><tr key={o.id}><td>#{o.publicId.slice(-8)}</td><td>{o.items.map(i=>`${i.serviceName} × ${i.quantity}`).join(", ")}</td><td><span className="pill">{o.status.replaceAll("_"," ")}</span></td><td>{o.paymentStatus}</td><td>{money(o.totalCents,o.currency)}</td><td>{o.createdAt.toLocaleDateString()}</td></tr>)}
      {orders.length===0 && <tr><td colSpan={6}>No orders yet.</td></tr>}
    </tbody></table></div>
  </section>;
}
