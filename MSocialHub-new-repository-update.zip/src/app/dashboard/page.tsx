import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { money } from "@/lib/format";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const [orders, totalCount, inProgressCount] = await Promise.all([
    prisma.order.findMany({ where: { userId: user.id }, include: { items: true }, orderBy: { createdAt: "desc" }, take: 8 }),
    prisma.order.count({ where: { userId: user.id } }),
    prisma.order.count({ where: { userId: user.id, status: { in: ["PAID", "AWAITING_FULFILLMENT", "PROCESSING"] } } })
  ]);
  return <section className="section">
    <div className="row" style={{alignItems:"start"}}><div><span className="eyebrow">CUSTOMER WORKSPACE</span><h1 style={{fontSize:42}}>Hello, {user.name.split(" ")[0]}.</h1><p>Keep an eye on your requests and upcoming work.</p></div>
      <div style={{display:"flex",gap:8,flexWrap:"wrap"}}><Link className="btn" href="/dashboard/new-order">New request</Link>{user.role === "ADMIN" && <Link className="btn secondary" href="/admin">Admin</Link>}</div>
    </div>
    <div className="grid" style={{marginTop:22}}>
      <div className="panel"><div className="muted" style={{fontSize:12}}>Total requests</div><div className="metric">{totalCount}</div></div>
      <div className="panel"><div className="muted" style={{fontSize:12}}>In progress</div><div className="metric">{inProgressCount}</div></div>
      <div className="panel"><div className="muted" style={{fontSize:12}}>Workspace mode</div><div className="metric" style={{fontSize:22}}>Mock supplier</div><div className="muted" style={{fontSize:12}}>Live orders disabled</div></div>
    </div>
    <div className="panel" style={{marginTop:22}}>
      <div className="row"><h2 style={{fontSize:20}}>Recent requests</h2><Link href="/dashboard/orders" style={{fontSize:13,textDecoration:"underline"}}>View all</Link></div>
      {orders.length === 0 ? <p>You have no requests yet. Browse the service catalog to get started.</p> : <div style={{overflowX:"auto"}}><table className="table"><thead><tr><th>Order</th><th>Items</th><th>Status</th><th>Total</th><th>Created</th></tr></thead><tbody>{orders.map(o=><tr key={o.id}><td>#{o.publicId.slice(-8)}</td><td>{o.items.map(i=>i.serviceName).join(", ")}</td><td><span className="pill">{o.status.replaceAll("_"," ")}</span></td><td>{money(o.totalCents,o.currency)}</td><td>{o.createdAt.toLocaleDateString()}</td></tr>)}</tbody></table></div>}
    </div>
    <form action="/logout" method="post" style={{marginTop:18}}><button className="btn secondary" type="submit">Sign out</button></form>
  </section>;
}
