"use server";

import { randomUUID } from "node:crypto";
import { z } from "zod";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

const schema = z.object({
  serviceId: z.string().min(1).max(64),
  targetUrl: z.union([
    z.literal(""),
    z.string().trim().max(500).url().refine(v => /^https?:\/\//i.test(v), "Only http(s) links are allowed")
  ]),
  customerNote: z.string().trim().max(1500).optional().or(z.literal(""))
});

export async function createOrderAction(formData: FormData) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const parsed = schema.safeParse({
    serviceId: formData.get("serviceId"),
    targetUrl: String(formData.get("targetUrl") ?? "").trim(),
    customerNote: formData.get("customerNote") || ""
  });
  if (!parsed.success) {
    const urlProblem = parsed.error.issues.some(i => i.path[0] === "targetUrl");
    redirect(`/dashboard/new-order?error=${urlProblem ? "url" : "invalid"}`);
  }
  const service = await prisma.service.findFirst({ where: { id: parsed.data.serviceId, active: true } });
  if (!service) redirect("/dashboard/new-order?error=unavailable");

  const key = randomUUID();
  const order = await prisma.order.create({
    data: {
      userId: user.id,
      status: "PENDING_PAYMENT",
      paymentStatus: "PENDING",
      subtotalCents: service.priceCents,
      totalCents: service.priceCents,
      currency: service.currency,
      customerNote: parsed.data.customerNote || null,
      idempotencyKey: key,
      supplierMode: "MOCK",
      items: {
        create: {
          serviceId: service.id,
          serviceName: service.name,
          unitPriceCents: service.priceCents,
          quantity: 1,
          lineTotalCents: service.priceCents,
          targetUrl: parsed.data.targetUrl || null
        }
      }
    }
  });

  if (process.env.PAYMENTS_MODE === "nowpayments") {
    const apiKey = process.env.NOWPAYMENTS_API_KEY;
    const appUrl = process.env.APP_URL;
    if (!apiKey || !process.env.NOWPAYMENTS_IPN_SECRET || !appUrl || !/^https:\/\//i.test(appUrl)) {
      await prisma.$transaction([
        prisma.order.update({ where: { id: order.id }, data: { status: "FAILED", paymentStatus: "FAILED" } }),
        prisma.auditLog.create({ data: { actorId: user.id, action: "PAYMENT_CONFIG_MISSING", targetType: "Order", targetId: order.id } })
      ]);
      redirect("/dashboard/orders?payment=unavailable");
    }
    try {
      const response = await fetch("https://api.nowpayments.io/v1/invoice", {
        method: "POST",
        headers: { "x-api-key": apiKey, "Content-Type": "application/json" },
        body: JSON.stringify({
          price_amount: (order.totalCents / 100).toFixed(2),
          price_currency: order.currency.toLowerCase(),
          order_id: order.id,
          order_description: `MSocialHub order ${order.publicId}`,
          ipn_callback_url: `${appUrl.replace(/\/$/, "")}/api/payments/nowpayments/webhook`,
          success_url: `${appUrl.replace(/\/$/, "")}/dashboard/orders?payment=return`,
          cancel_url: `${appUrl.replace(/\/$/, "")}/dashboard/orders?payment=cancelled`
        })
      });
      const invoice = await response.json() as { id?: string | number; invoice_url?: string; message?: string };
      if (!response.ok || !invoice.id || !invoice.invoice_url) throw new Error("NOWPayments invoice creation failed");
      await prisma.payment.create({ data: { orderId: order.id, provider: "NOWPAYMENTS", providerPaymentId: String(invoice.id), amountCents: order.totalCents, currency: order.currency, status: "PENDING" } });
      await prisma.auditLog.create({ data: { actorId: user.id, action: "PAYMENT_INVOICE_CREATED", targetType: "Order", targetId: order.id, metadata: { provider: "NOWPAYMENTS", invoiceId: String(invoice.id) } } });
      redirect(invoice.invoice_url);
    } catch (error) {
      if (error && typeof error === "object" && "digest" in error) throw error;
      await prisma.$transaction([
        prisma.order.update({ where: { id: order.id }, data: { status: "FAILED", paymentStatus: "FAILED" } }),
        prisma.auditLog.create({ data: { actorId: user.id, action: "PAYMENT_INVOICE_FAILED", targetType: "Order", targetId: order.id } })
      ]);
      redirect("/dashboard/orders?payment=error");
    }
  }
  redirect("/dashboard/orders?created=1");
}
