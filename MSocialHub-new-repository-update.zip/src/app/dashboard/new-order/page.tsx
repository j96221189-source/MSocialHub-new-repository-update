import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { money } from "@/lib/format";
import { createOrderAction } from "./actions";

const ERRORS: Record<string, string> = {
  invalid: "Please choose a service and keep notes under 1,500 characters.",
  url: "The profile link must be a full http:// or https:// address.",
  unavailable: "That service is no longer available. Please choose another one."
};

export const dynamic = "force-dynamic";

export default async function NewOrderPage({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const { error } = await searchParams;
  const services = await prisma.service.findMany({ where: { active: true }, orderBy: { priceCents: "asc" } });
  return <section className="section" style={{maxWidth:720}}>
    <span className="eyebrow">NEW REQUEST</span><h1 style={{fontSize:42}}>Tell us what you need.</h1>
    {error && <div className="notice" role="alert" style={{marginBottom:12}}>{ERRORS[error] ?? ERRORS.invalid}</div>}
    {process.env.PAYMENTS_MODE === "nowpayments" ? <div className="notice">Crypto checkout: you will be redirected to NOWPayments to pay this order. Fulfillment starts only after a verified payment notification.</div> : <div className="notice">Manual mode: this creates a request but does not charge a payment method or place a supplier order.</div>}
    <form action={createOrderAction} className="panel" style={{marginTop:18}}>
      <label className="label">Service<select className="input" name="serviceId" required defaultValue=""><option value="" disabled>Select a service</option>{services.map(s=><option key={s.id} value={s.id}>{s.name} — {money(s.priceCents,s.currency)}</option>)}</select></label>
      <label className="label">Public business/profile URL (optional)<input className="input" name="targetUrl" type="url" maxLength={500} placeholder="https://example.com/your-profile"/></label>
      <label className="label">Project notes<textarea className="input" name="customerNote" rows={4} maxLength={1500} placeholder="Describe your goals, audience and preferred style."/></label>
      <button className="btn" type="submit">{process.env.PAYMENTS_MODE === "nowpayments" ? "Continue to crypto payment" : "Create request"}</button>
    </form>
  </section>;
}
