import { mockSupplier } from "./mock";

// Live mode is intentionally not implemented in this starter.
// Environment flags cannot accidentally switch the application to a real supplier.
export const supplier = mockSupplier;
export const supplierMode = "mock" as const;
export const liveSupplierEnabled = false;
