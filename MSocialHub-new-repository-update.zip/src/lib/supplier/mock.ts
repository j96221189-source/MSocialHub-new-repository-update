import type { CatalogService, SupplierOrderInput, SupplierOrderResult } from "./types";

const catalog: CatalogService[] = [
  {
    id: "mock-content-review",
    name: "Social profile content review",
    platform: "Instagram / Facebook",
    description: "A manual review of profile presentation and content consistency.",
    pricePerK: 0,
    min: 1,
    max: 1,
    delivery: "manual"
  },
  {
    id: "mock-content-calendar",
    name: "Monthly content calendar",
    platform: "Multi-platform",
    description: "Content planning and post ideas. No artificial engagement is supplied.",
    pricePerK: 0,
    min: 1,
    max: 1,
    delivery: "manual"
  }
];

export const mockSupplier = {
  async getServices(): Promise<CatalogService[]> {
    return catalog;
  },
  async createOrder(input: SupplierOrderInput): Promise<SupplierOrderResult> {
    // Never calls an external provider and never spends funds.
    return {
      supplierOrderId: `MOCK-${input.idempotencyKey.slice(0, 12)}`,
      status: "PROCESSING",
      mode: "mock"
    };
  },
  async getOrderStatus(supplierOrderId: string): Promise<SupplierOrderResult> {
    return { supplierOrderId, status: "PROCESSING", mode: "mock" };
  }
};
