export type CatalogService = {
  id: string;
  name: string;
  platform: string;
  description: string;
  pricePerK: number;
  min: number;
  max: number;
  delivery: "automatic" | "manual";
};

export type SupplierOrderInput = {
  serviceId: string;
  link: string;
  quantity: number;
  idempotencyKey: string;
};

export type SupplierOrderResult = {
  supplierOrderId: string;
  status: "PROCESSING" | "COMPLETED" | "FAILED";
  mode: "mock" | "live";
};
