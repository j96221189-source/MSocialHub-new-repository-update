/** Pricing helpers. Amounts are integer cents to avoid floating-point currency errors. */
export type PriceBreakdown = { supplierCostCents: number; customerPriceCents: number; grossProfitCents: number; grossMarginPercent: number; markupPercent: number };

export function calculatePrice(supplierCostCents: number, markupPercent: number): PriceBreakdown {
  if (!Number.isSafeInteger(supplierCostCents) || supplierCostCents < 0) throw new Error("Supplier cost must be a non-negative integer number of cents.");
  if (!Number.isFinite(markupPercent) || markupPercent < 0 || markupPercent > 1000) throw new Error("Markup must be between 0% and 1000%.");
  const customerPriceCents = Math.round(supplierCostCents * (1 + markupPercent / 100));
  const grossProfitCents = customerPriceCents - supplierCostCents;
  return { supplierCostCents, customerPriceCents, grossProfitCents, grossMarginPercent: customerPriceCents === 0 ? 0 : grossProfitCents / customerPriceCents * 100, markupPercent };
}

/** Keep existing manually priced packages unchanged until a supplier cost is verified. */
export function priceForService(service: { priceCents: number; supplierCostCents: number | null; markupPercent: number | null }, defaultMarkupPercent = 50): PriceBreakdown | null {
  if (service.supplierCostCents == null) return null;
  return calculatePrice(service.supplierCostCents, service.markupPercent ?? defaultMarkupPercent);
}
